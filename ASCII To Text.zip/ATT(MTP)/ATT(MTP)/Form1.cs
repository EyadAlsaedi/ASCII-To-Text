﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ATT_MTP_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
 
        }

        private void dec_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
        }



        private void button1_Click(object sender, EventArgs e)
        {
            // Check if the input contains any letters
            if (tb1.Text.Any(c => char.IsLetter(c)))
            {
                StringBuilder asciiResult = new StringBuilder();
                foreach (char character in tb1.Text)
                {
                    // Convert each character to its ASCII value
                    int asciiValue = (int)character;
                    asciiResult.Append(asciiValue.ToString() + " ");
                }
                // Display the ASCII values
                result.Text = asciiResult.ToString().Trim();
                return;
            }

            try
            {
                // Original functionality to convert input to a character
                int code = int.Parse(tb1.Text);
                char character = (char)code;
                result.Text = character.ToString();
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid decimal number.");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Number is too large or too small for a character.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int number = int.Parse(tb1.Text);
                string binary = Convert.ToString(number, 2);
                result.Text = binary;
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid decimal number.");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Number is too large.");
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int number = int.Parse(tb1.Text);
                string hexadecimal = Convert.ToString(number, 16).ToUpper(); // ToUpper() to get uppercase letters
                result.Text = hexadecimal;
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid decimal number.");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Number is too large.");
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int number = int.Parse(tb1.Text);
                string octal = Convert.ToString(number, 8);
                result.Text = octal;
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid decimal number.");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Number is too large.");
            }
        }


        private void button5_Click(object sender, EventArgs e)
        {
            Dictionary<char, string> morseCodeMap = new Dictionary<char, string>
    {
        {'0', "-----"}, {'1', ".----"}, {'2', "..---"}, {'3', "...--"},
        {'4', "....-"}, {'5', "....."}, {'6', "-...."}, {'7', "--..."},
        {'8', "---.."}, {'9', "----."}
        // Add letters mapping if needed
    };

            StringBuilder morseCodeResult = new StringBuilder();
            string input = tb1.Text;

            try
            {
                foreach (char digit in input)
                {
                    if (morseCodeMap.ContainsKey(digit))
                    {
                        morseCodeResult.Append(morseCodeMap[digit] + " ");
                    }
                    else
                    {
                        MessageBox.Show($"Invalid character for Morse code: {digit}");
                        return;
                    }
                }

                result.Text = morseCodeResult.ToString().Trim();
            }
            catch (Exception ex) // Consider catching more specific exceptions if necessary
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

    }
}
